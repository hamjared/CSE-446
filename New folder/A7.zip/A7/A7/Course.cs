﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A7
{

    class Course
    {
        //Answers first part of 1.1
        public string Subject { get; set; }
        public int Code { get; set; }
        public int CourseId { get; set; }
        public string Title { get; set; }
        public string Location { get; set; }
        public string Instructor { get; set; }
    }
}
